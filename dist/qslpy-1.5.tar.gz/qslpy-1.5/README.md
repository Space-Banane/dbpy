# DbPy
## What is it?
#### DbPy is an python Module that makes qsl database interactions easyer 
## How Do i use it?
### Set:
#### To Set a Entry in A Table : `db.set("entry_name","data","table_name")`
### Get:
#### To get a Entry from a Table : `db_return = db.get("entry_name","table_name")`
### CreateTable:
#### To Create A Table : `db.createtable(`
### RemoveTabel:
#### To Remove A Table : `db.rmtable("Tablename")`
## Logs :
#### The Script returns strings whenever you make an interaction
